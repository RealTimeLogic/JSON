IoT
|   .appinfo - Used if run on FuguHub
|   .preload - Lua code for setting up socket and websocket connections (MAIN)
|   index.lsp - Redirects to led/json/index.lsp
|
/---led
    /---json
            arrow.png
            device.js - Browser JavaScript code for websocket con and DOM mgmnt
            device.lsp - Renders the initial LED page
            index.lsp - Intro page
            style.css


Load and run the app using Mako Server as follows:
mako -lIoT::IoT.zip
Alternatively, unpack the ZIP to directory IoT:
mako -lIoT::IoT

