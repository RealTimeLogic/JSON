
// Calculate WebSocket URL
function wsURL(path) {
    var l = window.location;
    if(path == undefined) path = l.pathname;
    return ((l.protocol === "https:") ? "wss://" : "ws://") +
        l.hostname +
        (l.port!=80 && l.port!=443 && l.port.length!=0 ? ":" + l.port : "") +
        path;
};




function setLedUiElem(ledId, on) {
    var lid="#led"+ledId;
    if(on)
        $(lid).removeClass('led-off');
    else
        $(lid).addClass('led-off');
};

$(function() {
    /* IP address is set in device.lsp */
    var ws = new WebSocket(wsURL(window.location.pathname+"?ipaddr="+ipaddr));
    ws.onopen = function() { $("#coninfo").empty(); };
    ws.onclose = function() { window.location="./"; };
    ws.onmessage = function(event) {
        var msg = JSON.parse(event.data);
        if(msg[0] == 'S')
        {
            msg=msg[1];
            $("#fs"+msg.id).prop('checked', msg.on);
            setLedUiElem(msg.id,msg.on);
        }
        else if(msg[0] == 'C') {
            alert(msg[1]);
            ws.onclose()
        }
        else {
            alert("Received invalid command: " + event.data);
        }
    };

    $('.flipswitch input').click(function(ev) {
        var ledId = $(this).prop('id').match(/(\d+)/)[0];
        ws.send(JSON.stringify(['S',{id:parseInt(ledId),on:this.checked}]));
    });

});


